// bank.js — общая библиотека для работы с банком

const API = 'http://127.0.0.1:8080/api';

// ===== ПУБЛИЧНЫЙ КЛЮЧ ИМПЕРАТОРА =====
export const EMPEROR_PUBLIC_KEY = 'FtQ/uJAUhl8xbl7ydC4A2zpLZvsZ7zCjjcPfjzwbQEk=';

// ===== РАБОТА С ДАННЫМИ =====
export async function saveData(filename, data) {
    try {
        await fetch(`${API}/data/app/bank/${filename}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: data })
        });
        return true;
    } catch (e) {
        console.error('Ошибка сохранения:', e);
        return false;
    }
}

export async function loadData(filename) {
    try {
        const res = await fetch(`${API}/data/app/bank/${filename}`);
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        console.error('Ошибка загрузки:', e);
        return null;
    }
}

// ===== БАЛАНСЫ (НОВАЯ СТРУКТУРА) =====

// Получить данные пользователя (баланс + pubkey)
export async function getUserData(userId) {
    const data = await loadData('users') || {};
    return data[userId] || { balance: 0, pubkey: null };
}

// Получить только баланс
export async function getBalance(userId) {
    const user = await getUserData(userId);
    return user.balance || 0;
}

// Получить публичный ключ пользователя
export async function getUserPubKey(userId) {
    const user = await getUserData(userId);
    return user.pubkey || null;
}

// Установить данные пользователя
export async function setUserData(userId, balance, pubkey) {
    const data = await loadData('users') || {};
    data[userId] = { balance, pubkey };
    await saveData('users', data);
    return data;
}

// Установить только баланс
export async function setBalance(userId, amount) {
    const user = await getUserData(userId);
    await setUserData(userId, amount, user.pubkey);
}

// Установить только публичный ключ
export async function setUserPubKey(userId, pubkey) {
    const user = await getUserData(userId);
    await setUserData(userId, user.balance, pubkey);
}

// ===== ИСТОРИЯ =====
export async function getHistory() {
    return await loadData('history') || [];
}

export async function addHistory(confirmation) {
    const history = await getHistory();
    history.push(confirmation);
    await saveData('history', history);
    return history;
}

// ===== КОНТАКТЫ (для удобства граждан) =====
export async function getContacts() {
    return await loadData('contacts') || [];
}

export async function addContact(name, id) {
    const contacts = await getContacts();
    contacts.push({ name, id });
    await saveData('contacts', contacts);
    return contacts;
}

export async function removeContact(index) {
    const contacts = await getContacts();
    contacts.splice(index, 1);
    await saveData('contacts', contacts);
    return contacts;
}

// ===== СОЗДАНИЕ ЧЕКА (без pubkey) =====
export async function createBill(from, to, amount) {
    const timestamp = Math.floor(Date.now() / 1000);
    
    const bill = {
        from: from,
        to: to,
        amount: amount,
        timestamp: timestamp
    };
    
    // Данные для подписи (без pubkey)
    const data = `${from}|${to}|${amount}|${timestamp}`;
    
    // Подписываем через ядро
    const signResult = await fetch(`${API}/crypto/sign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            use_stored: true
        })
    });
    
    if (!signResult.ok) {
        throw new Error('Ошибка подписи');
    }
    
    const signData = await signResult.json();
    bill.sign_from = signData.signature;
    
    return bill;
}

// ===== ПРОВЕРКА ПОДПИСИ ЧЕКА (по ключу из Центробанка) =====
export async function verifyBillSignature(bill) {
    // Получаем публичный ключ отправителя из Центробанка
    const pubkey = await getUserPubKey(bill.from);
    if (!pubkey) {
        return { valid: false, error: 'Публичный ключ отправителя не найден в Центробанке' };
    }
    
    const data = `${bill.from}|${bill.to}|${bill.amount}|${bill.timestamp}`;
    
    const verifyResult = await fetch(`${API}/crypto/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            signature: bill.sign_from,
            pub_key: pubkey
        })
    });
    
    const verifyData = await verifyResult.json();
    return { valid: verifyData.valid, error: null };
}

// ===== ПРОВЕРКА ПОДПИСИ ИМПЕРАТОРА =====
export async function verifyEmperorSignature(confirmation) {
    const bill = confirmation.bill;
    const data = `${bill.from}|${bill.to}|${bill.amount}|${confirmation.new_bal1}|${confirmation.new_bal2}|${confirmation.timestamp}`;
    
    const verifyResult = await fetch(`${API}/crypto/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            signature: confirmation.sign_emperor,
            pub_key: EMPEROR_PUBLIC_KEY
        })
    });
    
    const verifyData = await verifyResult.json();
    return verifyData.valid;
}

// ===== ПОДТВЕРЖДЕНИЕ ТРАНЗАКЦИИ (для Императора) =====
export async function confirmBill(bill, emperorPrivKey) {
    // 1. Проверяем, что отправитель зарегистрирован в Центробанке
    const fromUser = await getUserData(bill.from);
    if (!fromUser.pubkey) {
        throw new Error(`Отправитель #${bill.from} не зарегистрирован в Центробанке (нет публичного ключа)`);
    }
    
    // 2. Проверяем подпись отправителя
    const result = await verifyBillSignature(bill);
    if (!result.valid) {
        throw new Error(result.error || 'Неверная подпись отправителя');
    }
    
    // 3. Проверяем баланс отправителя
    if (fromUser.balance < bill.amount) {
        throw new Error(`Недостаточно средств. Баланс: ${fromUser.balance}`);
    }
    
    // 4. Проверяем двойную трату
    const history = await getHistory();
    const exists = history.some(h => 
        h.bill.from === bill.from && 
        h.bill.to === bill.to && 
        h.bill.amount === bill.amount && 
        h.bill.timestamp === bill.timestamp
    );
    if (exists) {
        throw new Error('Дублирующая транзакция');
    }
    
    // 5. Создаём получателя, если его нет (только баланс, pubkey позже)
    const toUser = await getUserData(bill.to);
    if (!toUser.pubkey) {
        // Получатель существует только с балансом
        await setUserData(bill.to, toUser.balance || 0, null);
        // Император должен будет ввести его публичный ключ позже
    }
    
    // 6. Обновляем балансы
    const newBal1 = fromUser.balance - bill.amount;
    const newBal2 = (toUser.balance || 0) + bill.amount;
    
    await setBalance(bill.from, newBal1);
    await setBalance(bill.to, newBal2);
    
    // 7. Создаём подтверждение
    const confirmation = {
        bill: bill,
        new_bal1: newBal1,
        new_bal2: newBal2,
        timestamp: Math.floor(Date.now() / 1000)
    };
    
    // 8. Подписываем Императором
    const data = `${bill.from}|${bill.to}|${bill.amount}|${newBal1}|${newBal2}|${confirmation.timestamp}`;
    
    const signResult = await fetch(`${API}/crypto/sign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            priv_key: emperorPrivKey,
            use_stored: false
        })
    });
    
    if (!signResult.ok) {
        throw new Error('Ошибка подписи Императора');
    }
    
    const signData = await signResult.json();
    confirmation.sign_emperor = signData.signature;
    
    // 9. Сохраняем в историю
    await addHistory(confirmation);
    
    return confirmation;
}

// ===== ОБРАБОТКА ПОДТВЕРЖДЁННОГО ЧЕКА (для граждан) =====
export async function processConfirmation(confirmation, userId) {
    // Проверяем подпись Императора
    const valid = await verifyEmperorSignature(confirmation);
    if (!valid) {
        throw new Error('Неверная подпись Императора');
    }
    
    const bill = confirmation.bill;
    
    if (bill.from === userId || bill.to === userId) {
        const newBalance = bill.from === userId ? 
            confirmation.new_bal1 : confirmation.new_bal2;
        await setBalance(userId, newBalance);
        await addHistory(confirmation);
        return { success: true, balance: newBalance };
    } else {
        throw new Error('Этот чек не для вас');
    }
}

// ===== ПОЛУЧЕНИЕ ID ПОЛЬЗОВАТЕЛЯ =====
export async function getUserId() {
    try {
        const res = await fetch(`${API}/data/main/id`);
        return await res.json();
    } catch (e) {
        return null;
    }
}

// ===== ПОЛУЧЕНИЕ ВСЕХ ПОЛЬЗОВАТЕЛЕЙ =====
export async function getAllUsers() {
    return await loadData('users') || {};
}

export default {
    EMPEROR_PUBLIC_KEY,
    saveData,
    loadData,
    getUserData,
    getBalance,
    getUserPubKey,
    setUserData,
    setBalance,
    setUserPubKey,
    getHistory,
    addHistory,
    getContacts,
    addContact,
    removeContact,
    createBill,
    verifyBillSignature,
    verifyEmperorSignature,
    processConfirmation,
    confirmBill,
    getUserId,
    getAllUsers
};