// bank.js — общая библиотека для работы с банком (v2)

const API = 'http://127.0.0.1:8080/api';

// ===== ПУБЛИЧНЫЙ КЛЮЧ ИМПЕРАТОРА (sig_pub_key) =====
export const EMPEROR_SIG_PUBKEY = 'DBwp0R3O3iIkv7r9j9GxCkFFwnEFjlPKMDMfYkuAag4=';

// ===== РАБОТА С ДАННЫМИ =====
export async function saveData(filename, data) {
    try {
        await fetch(`${API}/data/lib/bank/${filename}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: data })
        });
        return true;
    } catch (e) {
        console.error('Ошибка сохранения:', e);
        return false;
    }
}

export async function loadData(filename) {
    try {
        const res = await fetch(`${API}/data/lib/bank/${filename}`);
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        console.error('Ошибка загрузки:', e);
        return null;
    }
}

// ===== БАЛАНСЫ (ключ = sig_pub_key) =====

export async function getBalance(sigPubKey) {
    const balances = await loadData('balances') || {};
    return balances[sigPubKey] || 0;
}

export async function setBalance(sigPubKey, amount) {
    const balances = await loadData('balances') || {};
    balances[sigPubKey] = amount;
    await saveData('balances', balances);
    return balances;
}

export async function getAllBalances() {
    return await loadData('balances') || {};
}

// ===== ИСТОРИЯ =====
export async function getHistory() {
    return await loadData('history') || [];
}

export async function addHistory(confirmation) {
    const history = await getHistory();
    history.push(confirmation);
    await saveData('history', history);
    return history;
}

// ===== КОНТАКТЫ (храним sig_pub_key и enc_pub_key) =====
export async function getContacts() {
    return await loadData('contacts') || [];
}

export async function addContact(name, sigPubKey, encPubKey) {
    const contacts = await getContacts();
    if (!contacts.find(c => c.sig_pubkey === sigPubKey)) {
        contacts.push({ name, sig_pubkey: sigPubKey, enc_pubkey: encPubKey });
        await saveData('contacts', contacts);
    }
    return contacts;
}

export async function removeContact(index) {
    const contacts = await getContacts();
    contacts.splice(index, 1);
    await saveData('contacts', contacts);
    return contacts;
}

// ===== ПОЛУЧЕНИЕ КЛЮЧЕЙ ТЕКУЩЕГО ПОЛЬЗОВАТЕЛЯ =====
export async function getMyKeys() {
    try {
        const res = await fetch(`${API}/crypto/pubkey`);
        const data = await res.json();
        return {
            sig_pubkey: data.sig_pub_key || null,
            enc_pubkey: data.enc_pub_key || null,
            id: data.id || null
        };
    } catch (e) {
        return null;
    }
}

// ===== ПОЛУЧЕНИЕ ID (sig_pub_key) =====
export async function getUserId() {
    const keys = await getMyKeys();
    return keys ? keys.sig_pubkey : null;
}

// ===== СОЗДАНИЕ ЧЕКА =====
export async function createBill(fromSigPub, toSigPub, amount) {
    const timestamp = Math.floor(Date.now() / 1000);
    
    const bill = {
        from: fromSigPub,
        to: toSigPub,
        amount: amount,
        timestamp: timestamp
    };
    
    const data = `${fromSigPub}|${toSigPub}|${amount}|${timestamp}`;
    
    const signResult = await fetch(`${API}/crypto/sign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            use_stored: true
        })
    });
    
    if (!signResult.ok) {
        throw new Error('Ошибка подписи');
    }
    
    const signData = await signResult.json();
    bill.sign_from = signData.signature;
    
    return bill;
}

// ===== ПРОВЕРКА ПОДПИСИ ЧЕКА =====
export async function verifyBillSignature(bill) {
    const data = `${bill.from}|${bill.to}|${bill.amount}|${bill.timestamp}`;
    
    const verifyResult = await fetch(`${API}/crypto/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            signature: bill.sign_from,
            pub_key: bill.from  // from = sig_pub_key
        })
    });
    
    const verifyData = await verifyResult.json();
    return { valid: verifyData.valid, error: null };
}

// ===== ПРОВЕРКА ПОДПИСИ ИМПЕРАТОРА =====
export async function verifyEmperorSignature(confirmation) {
    const bill = confirmation.bill;
    const data = `${bill.from}|${bill.to}|${bill.amount}|${confirmation.new_bal1}|${confirmation.new_bal2}|${confirmation.timestamp}`;
    
    const verifyResult = await fetch(`${API}/crypto/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            signature: confirmation.sign_emperor,
            pub_key: EMPEROR_SIG_PUBKEY
        })
    });
    
    const verifyData = await verifyResult.json();
    return verifyData.valid;
}

// ===== ПОДТВЕРЖДЕНИЕ ТРАНЗАКЦИИ (для Императора) =====
export async function confirmBill(bill, emperorPrivKey) {
    // 1. Проверяем подпись отправителя
    const result = await verifyBillSignature(bill);
    if (!result.valid) {
        throw new Error(result.error || 'Неверная подпись отправителя');
    }
    
    // 2. Проверяем баланс отправителя
    const fromBalance = await getBalance(bill.from);
    if (fromBalance < bill.amount) {
        throw new Error(`Недостаточно средств. Баланс: ${fromBalance}`);
    }
    
    // 3. Проверяем двойную трату
    const history = await getHistory();
    const exists = history.some(h => 
        h.bill.from === bill.from && 
        h.bill.to === bill.to && 
        h.bill.amount === bill.amount && 
        h.bill.timestamp === bill.timestamp
    );
    if (exists) {
        throw new Error('Дублирующая транзакция');
    }
    
    // 4. Обновляем балансы
    const newBal1 = fromBalance - bill.amount;
    const newBal2 = await getBalance(bill.to) + bill.amount;
    
    await setBalance(bill.from, newBal1);
    await setBalance(bill.to, newBal2);
    
    // 5. Создаём подтверждение
    const confirmation = {
        bill: bill,
        new_bal1: newBal1,
        new_bal2: newBal2,
        timestamp: Math.floor(Date.now() / 1000)
    };
    
    // 6. Подписываем Императором
    const data = `${bill.from}|${bill.to}|${bill.amount}|${newBal1}|${newBal2}|${confirmation.timestamp}`;
    
    const signResult = await fetch(`${API}/crypto/sign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            data: data,
            priv_key: emperorPrivKey,
            use_stored: false
        })
    });
    
    if (!signResult.ok) {
        throw new Error('Ошибка подписи Императора');
    }
    
    const signData = await signResult.json();
    confirmation.sign_emperor = signData.signature;
    
    // 7. Сохраняем в историю
    await addHistory(confirmation);
    
    return confirmation;
}

// ===== ОБРАБОТКА ПОДТВЕРЖДЁННОГО ЧЕКА (для граждан) =====
export async function processConfirmation(confirmation, mySigPubKey) {
    const valid = await verifyEmperorSignature(confirmation);
    if (!valid) {
        throw new Error('Неверная подпись Императора');
    }
    
    const bill = confirmation.bill;
    
    if (bill.from === mySigPubKey || bill.to === mySigPubKey) {
        const newBalance = bill.from === mySigPubKey ? 
            confirmation.new_bal1 : confirmation.new_bal2;
        await setBalance(mySigPubKey, newBalance);
        await addHistory(confirmation);
        return { success: true, balance: newBalance };
    } else {
        throw new Error('Этот чек не для вас');
    }
}

export default {
    EMPEROR_SIG_PUBKEY,
    saveData,
    loadData,
    getBalance,
    setBalance,
    getAllBalances,
    getHistory,
    addHistory,
    getContacts,
    addContact,
    removeContact,
    getMyKeys,
    getUserId,
    createBill,
    verifyBillSignature,
    verifyEmperorSignature,
    processConfirmation,
    confirmBill
};

// Kdn9Au/LWPuR4tFprtJKhsxqWCJUzBBDl0qbLMyhIqo=