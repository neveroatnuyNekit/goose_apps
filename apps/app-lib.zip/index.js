// lib/app/index.js — универсальная библиотека для приложений
// Импортирует bank.js для банковских операций

import * as bank from '/lib/bank/index.js';

const API = 'http://127.0.0.1:8080/api';

// ===== ЭКСПОРТ ВСЕГО ИЗ BANK.JS =====
// Проксируем все функции из bank.js для удобства
export const {
    EMPEROR_SIG_PUBKEY,
    saveData,
    loadData,
    getBalance,
    setBalance,
    getAllBalances,
    getHistory,
    addHistory,
    getContacts,
    addContact,
    removeContact,
    getMyKeys,
    getUserId,
    createBill,
    verifyBillSignature,
    verifyEmperorSignature,
    processConfirmation,
    confirmBill
} = bank;

// Также экспортируем сам bank для прямого доступа
export { bank };

// ===== РАБОТА С ДАННЫМИ ПРИЛОЖЕНИЯ (своё хранилище) =====

export async function saveAppData(appName, key, data) {
    try {
        await fetch(`${API}/data/app/${appName}/${key}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: data })
        });
        return true;
    } catch (e) {
        console.error('Ошибка сохранения данных приложения:', e);
        return false;
    }
}

export async function loadAppData(appName, key) {
    try {
        const res = await fetch(`${API}/data/app/${appName}/${key}`);
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        console.error('Ошибка загрузки данных приложения:', e);
        return null;
    }
}

export async function saveAppDataAll(appName, data) {
    try {
        for (const [key, value] of Object.entries(data)) {
            await saveAppData(appName, key, value);
        }
        return true;
    } catch (e) {
        console.error('Ошибка сохранения данных приложения:', e);
        return false;
    }
}

export async function loadAppDataAll(appName) {
    try {
        const res = await fetch(`${API}/data/app/${appName}`);
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        console.error('Ошибка загрузки данных приложения:', e);
        return null;
    }
}

// ===== РАБОТА С ДАННЫМИ БИБЛИОТЕК =====

export async function saveLibData(libName, key, data) {
    try {
        await fetch(`${API}/data/lib/${libName}/${key}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: data })
        });
        return true;
    } catch (e) {
        console.error('Ошибка сохранения данных библиотеки:', e);
        return false;
    }
}

export async function loadLibData(libName, key) {
    try {
        const res = await fetch(`${API}/data/lib/${libName}/${key}`);
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        console.error('Ошибка загрузки данных библиотеки:', e);
        return null;
    }
}

// ===== КРИПТОГРАФИЯ (обёртки для удобства) =====

export async function signData(data) {
    try {
        const res = await fetch(`${API}/crypto/sign`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: data, use_stored: true })
        });
        if (!res.ok) throw new Error('Ошибка подписи');
        const result = await res.json();
        return result.signature;
    } catch (e) {
        console.error('Ошибка подписи:', e);
        return null;
    }
}

export async function verifySignature(data, signature, pubKey) {
    try {
        const res = await fetch(`${API}/crypto/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data, signature, pub_key: pubKey })
        });
        const result = await res.json();
        return result.valid;
    } catch (e) {
        console.error('Ошибка проверки подписи:', e);
        return false;
    }
}

export async function encryptMessage(message, encPubKey) {
    try {
        const res = await fetch(`${API}/crypto/encrypt`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message, enc_pub_key: encPubKey })
        });
        const result = await res.json();
        return result.encrypted;
    } catch (e) {
        console.error('Ошибка шифрования:', e);
        return null;
    }
}

export async function decryptMessage(encrypted, encPubKey) {
    try {
        const res = await fetch(`${API}/crypto/decrypt`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ encrypted, enc_pub_key: encPubKey, use_stored: true })
        });
        const result = await res.json();
        return result.decrypted;
    } catch (e) {
        console.error('Ошибка расшифровки:', e);
        return null;
    }
}

// ===== МОНЕТИЗАЦИЯ (баланс приложения) =====

export async function getAppBalance(appSigPubKey) {
    try {
        const res = await fetch(`${API}/data/lib/bank/app_balances/${appSigPubKey}`);
        if (!res.ok) return 0;
        return await res.json();
    } catch (e) {
        return 0;
    }
}

export async function setAppBalance(appSigPubKey, amount) {
    try {
        await fetch(`${API}/data/lib/bank/app_balances/${appSigPubKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ value: amount })
        });
        return true;
    } catch (e) {
        return false;
    }
}

// ===== УТИЛИТЫ =====

export function shortenKey(key, len = 16) {
    if (!key) return '—';
    if (key.length <= len) return key;
    return key.substring(0, len) + '...';
}

export function generateRandomId() {
    return Math.random().toString(36).substring(2, 10);
}

export function formatDate(timestamp) {
    return new Date(timestamp * 1000).toLocaleString();
}

// ===== ДЕФОЛТНЫЙ ЭКСПОРТ =====
export default {
    // Из bank.js
    EMPEROR_SIG_PUBKEY: bank.EMPEROR_SIG_PUBKEY,
    getBalance: bank.getBalance,
    setBalance: bank.setBalance,
    getAllBalances: bank.getAllBalances,
    getHistory: bank.getHistory,
    addHistory: bank.addHistory,
    getContacts: bank.getContacts,
    addContact: bank.addContact,
    removeContact: bank.removeContact,
    getMyKeys: bank.getMyKeys,
    getUserId: bank.getUserId,
    createBill: bank.createBill,
    verifyBillSignature: bank.verifyBillSignature,
    verifyEmperorSignature: bank.verifyEmperorSignature,
    processConfirmation: bank.processConfirmation,
    confirmBill: bank.confirmBill,
    saveData: bank.saveData,
    loadData: bank.loadData,
    bank: bank,
    
    // Свои функции
    saveAppData,
    loadAppData,
    saveAppDataAll,
    loadAppDataAll,
    saveLibData,
    loadLibData,
    signData,
    verifySignature,
    encryptMessage,
    decryptMessage,
    getAppBalance,
    setAppBalance,
    shortenKey,
    generateRandomId,
    formatDate
};